public class Pontos
{
    public static void Main()
    static int nPos, nDes, nAux;
    {
        console.Writeline("informe um numero");
        console.convert.toint(16)
        nDis=0;
        while (nPos>400)
        {
            nPos=nPos-400
            nDist=nDist + 400
        }
        if (nPos<200)
        {
            Console.Writeline(nDist);
        else
            Console.WriteLine(nDist + 400)
        }
        
    }
}

