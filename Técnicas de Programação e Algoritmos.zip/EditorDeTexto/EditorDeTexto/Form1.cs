using System.Drawing.Imaging;
using System.Windows.Forms;

namespace EditorDeTexto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrir = new OpenFileDialog();
            abrir.Filter = "Imagens (*.bmp;*.jpg;*.jpeg;*.png)|*.bmp;*.jpg;*.jpeg;*.png|Todos os Arquivos (*.*)|*.*";

            abrir.ShowDialog();
            pictureBox1.Image = Bitmap.FromFile(abrir.FileName);
            if (abrir.FileName != "")
                switch (abrir.FilterIndex)
                {
                    case 1: pictureBox1.Image.Save(abrir.FileName, ImageFormat.Png); break;
                    case 2: pictureBox1.Image.Save(abrir.FileName, ImageFormat.Jpeg); break;
                    case 3: pictureBox1.Image.Save(abrir.FileName, ImageFormat.Gif); break;
                    
                }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(pictureBox1.Text);
            MessageBox.Show(pictureBox1 + "copiado");
        }
    }
}
