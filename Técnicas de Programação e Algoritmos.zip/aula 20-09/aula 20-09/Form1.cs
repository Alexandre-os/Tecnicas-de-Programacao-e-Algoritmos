namespace aula_20_09
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Novo(object sender, EventArgs e)
        {
            rtb_painel.Clear();
        }

        private void Abrir(object sender, EventArgs e)
        {
            OpenFileDialog Abrir = new OpenFileDialog();
            Abrir.ShowDialog();
        }

        private void Salvar(object sender, EventArgs e)
        {
            SaveFileDialog Salvar = new SaveFileDialog();

            Salvar.Filter = "ArquivoTXT| *.txt";
            Salvar.ShowDialog();
        }

        private void Copiar(object sender, EventArgs e)
        {
            rtb_painel.Copy();
        }

        private void Colar(object sender, EventArgs e)
        {
            rtb_painel.Paste();
        }

        private void SelecionarTudo(object sender, EventArgs e)
        {
            rtb_painel.SelectAll();
        }

        private void Sair(object sender, EventArgs e)
        {
            
        }
    }
}