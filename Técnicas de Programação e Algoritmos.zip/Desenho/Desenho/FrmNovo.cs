﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desenho
{
    public partial class FrmNovo : Form
    {
        public FrmNovo()
        {
            InitializeComponent();
        }

        private void pnlCorFundo_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
