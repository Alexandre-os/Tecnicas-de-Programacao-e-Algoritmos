namespace Desenho
{
    public partial class frmlPrincipal : Form
    {
        Graphics oImagem;
        Point oPosicao = new Point();

        public frmlPrincipal()
        {
            InitializeComponent();
        }

        private void imgDesenho_MouseDown(object sender, MouseEventArgs e)
        {
            oPosicao.X = e.X;
            oPosicao.Y = e.Y;

        }

        private void imgDesenho_MouseUp(object sender, MouseEventArgs e)
        {
            oImagem.DrawRectangle(new Pen(Color.Indigo, 10), oPosicao.X, oPosicao.Y, e.X - oPosicao.X, e.Y - oPosicao.Y);
            imgDesenho.Refresh();
        }

        private void frmlPrincipal_Load(object sender, EventArgs e)
        {
            imgDesenho.Image = new Bitmap(imgDesenho.Width, imgDesenho.Height);
            oImagem = Graphics.FromImage(imgDesenho.Image);
        }
    }
}