﻿namespace Desenho
{
    partial class FrmNovo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbLargura = new Label();
            lbAltura = new Label();
            txtLargura = new TextBox();
            txtAltura = new TextBox();
            pnlCorFundo = new Panel();
            btnCancelar = new Button();
            btnOk = new Button();
            SuspendLayout();
            // 
            // lbLargura
            // 
            lbLargura.AutoSize = true;
            lbLargura.Location = new Point(37, 50);
            lbLargura.Name = "lbLargura";
            lbLargura.Size = new Size(71, 25);
            lbLargura.TabIndex = 0;
            lbLargura.Text = "Largura";
            // 
            // lbAltura
            // 
            lbAltura.AutoSize = true;
            lbAltura.Location = new Point(37, 84);
            lbAltura.Name = "lbAltura";
            lbAltura.Size = new Size(59, 25);
            lbAltura.TabIndex = 1;
            lbAltura.Text = "Altura";
            // 
            // txtLargura
            // 
            txtLargura.Location = new Point(117, 47);
            txtLargura.Name = "txtLargura";
            txtLargura.Size = new Size(150, 31);
            txtLargura.TabIndex = 2;
            txtLargura.Text = "800";
            txtLargura.TextAlign = HorizontalAlignment.Right;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(117, 84);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 3;
            txtAltura.Text = "600";
            txtAltura.TextAlign = HorizontalAlignment.Right;
            // 
            // pnlCorFundo
            // 
            pnlCorFundo.BackColor = SystemColors.Window;
            pnlCorFundo.BorderStyle = BorderStyle.FixedSingle;
            pnlCorFundo.Location = new Point(273, 47);
            pnlCorFundo.Name = "pnlCorFundo";
            pnlCorFundo.Size = new Size(80, 68);
            pnlCorFundo.TabIndex = 4;
            pnlCorFundo.Paint += pnlCorFundo_Paint;
            // 
            // btnCancelar
            // 
            btnCancelar.DialogResult = DialogResult.Cancel;
            btnCancelar.Location = new Point(117, 121);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(98, 34);
            btnCancelar.TabIndex = 5;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            btnOk.DialogResult = DialogResult.OK;
            btnOk.Location = new Point(221, 121);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(89, 34);
            btnOk.TabIndex = 6;
            btnOk.Text = "Criar";
            btnOk.UseVisualStyleBackColor = true;
            // 
            // FrmNovo
            // 
            AcceptButton = btnOk;
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = btnCancelar;
            ClientSize = new Size(396, 183);
            ControlBox = false;
            Controls.Add(btnOk);
            Controls.Add(btnCancelar);
            Controls.Add(pnlCorFundo);
            Controls.Add(txtAltura);
            Controls.Add(txtLargura);
            Controls.Add(lbAltura);
            Controls.Add(lbLargura);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "FrmNovo";
            ShowInTaskbar = false;
            Text = "Novo Arquivo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbLargura;
        private Label lbAltura;
        private TextBox txtLargura;
        private TextBox txtAltura;
        private Panel pnlCorFundo;
        private Button btnCancelar;
        private Button btnOk;
    }
}