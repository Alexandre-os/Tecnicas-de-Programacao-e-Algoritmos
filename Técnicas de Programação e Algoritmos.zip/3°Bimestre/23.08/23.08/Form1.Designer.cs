﻿namespace _23._08
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C = new Button();
            Sete = new Button();
            Quatro = new Button();
            Um = new Button();
            Divisao = new Button();
            Oito = new Button();
            Cinco = new Button();
            Dois = new Button();
            Multiplicacao = new Button();
            Nove = new Button();
            Seis = new Button();
            Tres = new Button();
            Zero = new Button();
            virgula = new Button();
            igual = new Button();
            invercao = new Button();
            adicao = new Button();
            Subtracao = new Button();
            Resultado = new TextBox();
            SuspendLayout();
            // 
            // C
            // 
            C.Location = new Point(101, 130);
            C.Name = "C";
            C.Size = new Size(57, 34);
            C.TabIndex = 0;
            C.Text = "C";
            C.UseVisualStyleBackColor = true;
            C.Click += C_Click;
            // 
            // Sete
            // 
            Sete.Location = new Point(101, 170);
            Sete.Name = "Sete";
            Sete.Size = new Size(57, 34);
            Sete.TabIndex = 1;
            Sete.Text = "7";
            Sete.UseVisualStyleBackColor = true;
            Sete.Click += button2_Click;
            // 
            // Quatro
            // 
            Quatro.Location = new Point(101, 210);
            Quatro.Name = "Quatro";
            Quatro.Size = new Size(57, 34);
            Quatro.TabIndex = 2;
            Quatro.Text = "4";
            Quatro.UseVisualStyleBackColor = true;
            Quatro.Click += Quatro_Click;
            // 
            // Um
            // 
            Um.Location = new Point(101, 250);
            Um.Name = "Um";
            Um.Size = new Size(57, 34);
            Um.TabIndex = 3;
            Um.Text = "1";
            Um.UseVisualStyleBackColor = true;
            Um.Click += Um_Click;
            // 
            // Divisao
            // 
            Divisao.Location = new Point(164, 130);
            Divisao.Name = "Divisao";
            Divisao.Size = new Size(59, 34);
            Divisao.TabIndex = 4;
            Divisao.Text = "/";
            Divisao.UseVisualStyleBackColor = true;
            Divisao.Click += Divisao_Click;
            // 
            // Oito
            // 
            Oito.Location = new Point(164, 170);
            Oito.Name = "Oito";
            Oito.Size = new Size(59, 34);
            Oito.TabIndex = 5;
            Oito.Text = "8";
            Oito.UseVisualStyleBackColor = true;
            Oito.Click += Oito_Click;
            // 
            // Cinco
            // 
            Cinco.Location = new Point(164, 210);
            Cinco.Name = "Cinco";
            Cinco.Size = new Size(59, 34);
            Cinco.TabIndex = 6;
            Cinco.Text = "5";
            Cinco.UseVisualStyleBackColor = true;
            Cinco.Click += Cinco_Click;
            // 
            // Dois
            // 
            Dois.Location = new Point(164, 250);
            Dois.Name = "Dois";
            Dois.Size = new Size(59, 34);
            Dois.TabIndex = 7;
            Dois.Text = "2";
            Dois.UseVisualStyleBackColor = true;
            Dois.Click += Dois_Click;
            // 
            // Multiplicacao
            // 
            Multiplicacao.Location = new Point(229, 130);
            Multiplicacao.Name = "Multiplicacao";
            Multiplicacao.Size = new Size(58, 34);
            Multiplicacao.TabIndex = 8;
            Multiplicacao.Text = "X";
            Multiplicacao.UseVisualStyleBackColor = true;
            Multiplicacao.Click += Multiplicacao_Click;
            // 
            // Nove
            // 
            Nove.Location = new Point(229, 170);
            Nove.Name = "Nove";
            Nove.Size = new Size(58, 34);
            Nove.TabIndex = 9;
            Nove.Text = "9";
            Nove.UseVisualStyleBackColor = true;
            Nove.Click += button10_Click;
            // 
            // Seis
            // 
            Seis.Location = new Point(229, 210);
            Seis.Name = "Seis";
            Seis.Size = new Size(58, 34);
            Seis.TabIndex = 10;
            Seis.Text = "6";
            Seis.UseVisualStyleBackColor = true;
            Seis.Click += Seis_Click;
            // 
            // Tres
            // 
            Tres.Location = new Point(229, 250);
            Tres.Name = "Tres";
            Tres.Size = new Size(58, 34);
            Tres.TabIndex = 11;
            Tres.Text = "3";
            Tres.UseVisualStyleBackColor = true;
            Tres.Click += Tres_Click;
            // 
            // Zero
            // 
            Zero.Location = new Point(101, 290);
            Zero.Name = "Zero";
            Zero.Size = new Size(122, 34);
            Zero.TabIndex = 12;
            Zero.Text = "0";
            Zero.UseVisualStyleBackColor = true;
            Zero.Click += Zero_Click;
            // 
            // virgula
            // 
            virgula.Location = new Point(229, 290);
            virgula.Name = "virgula";
            virgula.Size = new Size(58, 34);
            virgula.TabIndex = 13;
            virgula.Text = ",";
            virgula.UseVisualStyleBackColor = true;
            virgula.Click += virgula_Click;
            // 
            // igual
            // 
            igual.Location = new Point(293, 250);
            igual.Name = "igual";
            igual.Size = new Size(62, 74);
            igual.TabIndex = 14;
            igual.Text = "=";
            igual.UseVisualStyleBackColor = true;
            igual.Click += igual_Click;
            // 
            // invercao
            // 
            invercao.Location = new Point(293, 210);
            invercao.Name = "invercao";
            invercao.Size = new Size(62, 34);
            invercao.TabIndex = 15;
            invercao.Text = "I";
            invercao.UseVisualStyleBackColor = true;
            invercao.Click += invercao_Click;
            // 
            // adicao
            // 
            adicao.Location = new Point(293, 170);
            adicao.Name = "adicao";
            adicao.Size = new Size(62, 34);
            adicao.TabIndex = 16;
            adicao.Text = "+";
            adicao.UseVisualStyleBackColor = true;
            adicao.Click += adicao_Click;
            // 
            // Subtracao
            // 
            Subtracao.Location = new Point(293, 130);
            Subtracao.Name = "Subtracao";
            Subtracao.Size = new Size(62, 34);
            Subtracao.TabIndex = 17;
            Subtracao.Text = "-";
            Subtracao.UseVisualStyleBackColor = true;
            Subtracao.Click += Subtracao_Click;
            // 
            // Resultado
            // 
            Resultado.Location = new Point(101, 93);
            Resultado.Name = "Resultado";
            Resultado.Size = new Size(254, 31);
            Resultado.TabIndex = 18;
            Resultado.TextChanged += Resultado_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Resultado);
            Controls.Add(Subtracao);
            Controls.Add(adicao);
            Controls.Add(invercao);
            Controls.Add(igual);
            Controls.Add(virgula);
            Controls.Add(Zero);
            Controls.Add(Tres);
            Controls.Add(Seis);
            Controls.Add(Nove);
            Controls.Add(Multiplicacao);
            Controls.Add(Dois);
            Controls.Add(Cinco);
            Controls.Add(Oito);
            Controls.Add(Divisao);
            Controls.Add(Um);
            Controls.Add(Quatro);
            Controls.Add(Sete);
            Controls.Add(C);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Button C;
        private Button Sete;
        private Button Quatro;
        private Button Um;
        private Button Divisao;
        private Button Oito;
        private Button Cinco;
        private Button Dois;
        private Button Multiplicacao;
        private Button Nove;
        private Button Seis;
        private Button Tres;
        private Button Zero;
        private Button virgula;
        private Button igual;
        private Button invercao;
        private Button adicao;
        private Button Subtracao;
        private TextBox Resultado;
    }
}