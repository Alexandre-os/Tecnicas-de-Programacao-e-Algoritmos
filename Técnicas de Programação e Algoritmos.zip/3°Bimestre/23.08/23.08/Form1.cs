namespace _23._08
{
    public partial class Form1 : Form
    {
        static int numero, numero1, numero2, operacao;
        public Form1()
        {
            InitializeComponent();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            numero1 = '7';
            numero2 = '7';
        }

        private void button10_Click(object sender, EventArgs e)
        {
            numero1 = '9';
            numero2 = '9';
        }

        private void igual_Click(object sender, EventArgs e)
        {
            operacao = '=';
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void C_Click(object sender, EventArgs e)
        {
            Resultado = null;
        }

        private void Divisao_Click(object sender, EventArgs e)
        {
            operacao = '/';
        }

        private void Multiplicacao_Click(object sender, EventArgs e)
        {
            operacao = 'X';
        }

        private void Subtracao_Click(object sender, EventArgs e)
        {
            operacao = '-';
        }

        private void Oito_Click(object sender, EventArgs e)
        {
            numero1 = '8';
            numero2 = '8';
        }

        private void Quatro_Click(object sender, EventArgs e)
        {
            numero1 = '4';
            numero2 = '4';
        }

        private void Cinco_Click(object sender, EventArgs e)
        {
            numero1 = '5';
            numero2 = '5';
        }

        private void Seis_Click(object sender, EventArgs e)
        {
            numero1 = '6';
            numero2 = '6';
        }

        private void Um_Click(object sender, EventArgs e)
        {
            numero1 = '1';
            numero2 = '1';
        }

        private void Dois_Click(object sender, EventArgs e)
        {
            numero1 = '2';
            numero2 = '2';
        }

        private void Tres_Click(object sender, EventArgs e)
        {
            numero1 = '3';
            numero2 = '3';
        }

        private void Zero_Click(object sender, EventArgs e)
        {
            numero1 = '0';
            numero2 = '0';
        }

        private void virgula_Click(object sender, EventArgs e)
        {

        }

        private void invercao_Click(object sender, EventArgs e)
        {
            operacao = 'I';
        }

        private void adicao_Click(object sender, EventArgs e)
        {
            operacao = '+';
        }

        private void Resultado_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine(numero1);
            Console.WriteLine(numero2);
            Console.WriteLine(operacao);

            switch (operacao)
            {
                case '+': Resultado.Text = (Convert.ToInt32(numero1) + Convert.ToInt32(numero2)).ToString(); break;
                case '-': Resultado.Text = (Convert.ToInt32(numero1) - Convert.ToInt32(numero2)).ToString(); break;
                case 'x': Resultado.Text = (Convert.ToInt32(numero1) * Convert.ToInt32(numero2)).ToString(); break;
                case '/': Resultado.Text = (Convert.ToInt32(numero1) / Convert.ToInt32(numero2)).ToString(); break;
                case '=': Console.WriteLine(Resultado.Text); break;
            }
            switch (numero1)
            {
                case '1':
                    Console.WriteLine("1");break;
                case '2': 
                    Console.WriteLine("2");break;
                case '3': 
                    Console.WriteLine("3");break;
                case '4': 
                    Console.WriteLine("4");break;
                case '5':
                    Console.WriteLine("5");break;
                case '6':
                    Console.WriteLine("6");break;
                case '7':
                    Console.WriteLine("7");break;
                case '8':
                    Console.WriteLine("8");break;
                case '9':
                    Console.WriteLine("9");break;
                case '0':
                    Console.WriteLine("0"); break;

            }

        }
    }
}