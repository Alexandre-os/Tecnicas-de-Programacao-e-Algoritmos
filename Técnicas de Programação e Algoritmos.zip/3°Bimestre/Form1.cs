namespace Aula020824
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Vermelho.Checked) this.BackColor = Color.Red;
            if (Verde.Checked) this.BackColor = Color.Green;
            if (Azul.Checked) this.BackColor = Color.Blue;
            if (Vermelho.Checked && Verde.Checked) this.BackColor = Color.Yellow;
            if (Vermelho.Checked && Azul.Checked) this.BackColor = Color.Purple;
            if (Azul.Checked && Verde.Checked) this.BackColor = Color.Cyan;
            if (Vermelho.Checked && Verde.Checked && Azul.Checked) this.BackColor = Color.White;
            if (!Vermelho.Checked && !Verde.Checked && !Azul.Checked) this.BackColor = Color.Black;

        }

        }
    }
