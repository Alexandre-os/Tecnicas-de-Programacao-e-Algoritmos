﻿internal static class CalculadoraHelpersHelpersHelpers
{

    private static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nCalculadora Simples:");
            Console.WriteLine("Digite um número ou operação (+, -, *, /). Use 'c' para limpar, 'i' para inverter, 'd' para casa decimal, '=' para resultado e 'q' para sair.");

            var comando = Console.ReadKey().KeyChar;
            Console.WriteLine();  // Pula a linha após o comando

            if (comando == 'q')
            {
                break;
            }
            else if (char.IsDigit(comando))
            {
                pressionarNumero(char.GetNumericValue(comando));
            }
            else if (comando == '+' || comando == '-' || comando == '*' || comando == '/')
            {
                pressionarOperacao(comando);
            }
            else if (comando == 'c')
            {
                pressionarLimpar();
            }
            else if (comando == 'd')
            {
                pressionarCasaDecimal();
            }
            else if (comando == 'i')
            {
                pressionarInverter();
            }
            else if (comando == '=')
            {
                pressionarResultado();
            }
            else
            {
                Console.WriteLine("Comando inválido.");
            }
        }
    }
}