namespace _23._08._24
{
    using System;

    public class Calculadora
    {
        static double numeroAtual = 0.0;
        static double numeroArmazenado = 0.0;
        static char operacaoSelecionada = '\0';
        static bool temPontoDecimal = false;

        static void pressionarNumero(double numero)
        {
            if (temPontoDecimal)
            {
                numeroAtual += numero / 10.0;
                temPontoDecimal = false; // Reset para o pr�ximo n�mero
            }
            else
            {
                numeroAtual = numeroAtual * 10.0 + numero;
            }
            Console.WriteLine($"N�mero atual: {numeroAtual:F1}");
        }

        static void pressionarOperacao(char operacao)
        {
            numeroArmazenado = numeroAtual;
            operacaoSelecionada = operacao;
            numeroAtual = 0.0;
            Console.WriteLine($"Opera��o selecionada: {operacaoSelecionada}");
        }

        static void pressionarLimpar()
        {
            numeroAtual = 0.0;
            numeroArmazenado = 0.0;
            operacaoSelecionada = '\0';
            temPontoDecimal = false;
            Console.WriteLine("Calculadora limpa.");
        }

        static void pressionarCasaDecimal()
        {
            temPontoDecimal = true; // Permite adicionar uma casa decimal
        }

        static void pressionarInverter()
        {
            numeroAtual = -numeroAtual;
            Console.WriteLine($"N�mero atual invertido: {numeroAtual:F1}");
        }

        static void pressionarResultado()
        {
            switch (operacaoSelecionada)
            {
                case '+':
                    numeroAtual = numeroArmazenado + numeroAtual;
                    break;
                case '-':
                    numeroAtual = numeroArmazenado - numeroAtual;
                    break;
                case '*':
                    numeroAtual = numeroArmazenado * numeroAtual;
                    break;
                case '/':
                    if (numeroAtual != 0)
                    {
                        numeroAtual = numeroArmazenado / numeroAtual;
                    }
                    else
                    {
                        Console.WriteLine("Erro: Divis�o por zero");
                        numeroAtual = 0.0;
                    }
                    break;
                default:
                    Console.WriteLine("Nenhuma opera��o selecionada.");
                    break;
            }
            operacaoSelecionada = '\0';
            Console.WriteLine($"Resultado: {numeroAtual:F1}");
        }
    }
}