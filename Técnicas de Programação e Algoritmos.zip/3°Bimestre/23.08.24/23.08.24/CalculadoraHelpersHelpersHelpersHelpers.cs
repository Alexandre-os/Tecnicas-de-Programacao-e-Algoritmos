﻿internal static class CalculadoraHelpersHelpersHelpersHelpers
{
}