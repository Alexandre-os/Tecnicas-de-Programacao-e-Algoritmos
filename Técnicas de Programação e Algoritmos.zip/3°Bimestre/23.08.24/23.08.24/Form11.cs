﻿namespace _23._08._24
{
    internal class Form1 : Form
    {
    }
}