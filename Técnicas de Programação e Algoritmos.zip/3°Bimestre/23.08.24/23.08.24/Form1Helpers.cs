﻿using System;

class Calculadora
{
    static double numeroAtual = 0.0;
    static double numeroArmazenado = 0.0;
    static char operacaoSelecionada = '\0';
    static bool temPontoDecimal = false;

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nCalculadora Simples:");
            Console.WriteLine("Digite um número ou operação (+, -, *, /). Use 'c' para limpar, 'i' para inverter, 'd' para casa decimal, '=' para resultado e 'q' para sair.");

            var comando = Console.ReadKey().KeyChar;
            Console.WriteLine();  // Pula a linha após o comando

            if (comando == 'q')
            {
                break;
            }
            else if (char.IsDigit(comando))
            {
                pressionarNumero(char.GetNumericValue(comando));
            }
            else if (comando == '+' || comando == '-' || comando == '*' || comando == '/')
            {
                pressionarOperacao(comando);
            }
            else if (comando == 'c')
            {
                pressionarLimpar();
            }
            else if (comando == 'd')
            {
                pressionarCasaDecimal();
            }
            else if (comando == 'i')
            {
                pressionarInverter();
            }
            else if (comando == '=')
            {
                pressionarResultado();
            }
            else
            {
                Console.WriteLine("Comando inválido.");
            }
        }
    }

    static void pressionarNumero(double numero)
    {
        if (temPontoDecimal)
        {
            numeroAtual += numero / 10.0;
            temPontoDecimal = false; // Reset para o próximo número
        }
        else
        {
            numeroAtual = numeroAtual * 10.0 + numero;
        }
        Console.WriteLine($"Número atual: {numeroAtual:F1}");
    }

    static void pressionarOperacao(char operacao)
    {
        numeroArmazenado = numeroAtual;
        operacaoSelecionada = operacao;
        numeroAtual = 0.0;
        Console.WriteLine($"Operação selecionada: {operacaoSelecionada}");
    }

    static void pressionarLimpar()
    {
        numeroAtual = 0.0;
        numeroArmazenado = 0.0;
        operacaoSelecionada = '\0';
        temPontoDecimal = false;
        Console.WriteLine("Calculadora limpa.");
    }

    static void pressionarCasaDecimal()
    {
        temPontoDecimal = true; // Permite adicionar uma casa decimal
    }

    static void pressionarInverter()
    {
        numeroAtual = -numeroAtual;
        Console.WriteLine($"Número atual invertido: {numeroAtual:F1}");
    }

    static void pressionarResultado()
    {
        switch (operacaoSelecionada)
        {
            case '+':
                numeroAtual = numeroArmazenado + numeroAtual;
                break;
            case '-':
                numeroAtual = numeroArmazenado - numeroAtual;
                break;
            case '*':
                numeroAtual = numeroArmazenado * numeroAtual;
                break;
            case '/':
                if (numeroAtual != 0)
                {
                    numeroAtual = numeroArmazenado / numeroAtual;
                }
                else
                {
                    Console.WriteLine("Erro: Divisão por zero");
                    numeroAtual = 0.0;
                }
                break;
            default:
                Console.WriteLine("Nenhuma operação selecionada.");
                break;
        }
        operacaoSelecionada = '\0';
        Console.WriteLine($"Resultado: {numeroAtual:F1}");
    }
}