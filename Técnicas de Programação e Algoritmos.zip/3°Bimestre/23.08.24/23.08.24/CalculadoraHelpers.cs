﻿internal static class CalculadoraHelpers
{
}