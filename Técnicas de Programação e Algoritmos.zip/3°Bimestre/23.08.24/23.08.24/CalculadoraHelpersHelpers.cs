﻿internal static class CalculadoraHelpersHelpers
{
}