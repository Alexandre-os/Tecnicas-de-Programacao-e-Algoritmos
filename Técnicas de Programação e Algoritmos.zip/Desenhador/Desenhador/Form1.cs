using System.Drawing.Drawing2D;

namespace Desenhador
{
    public partial class fnmPrincipal : Form
    {
        Graphics oimagem;
        Point oPosicao = new Point();

        public fnmPrincipal()
        {
            InitializeComponent();
        }

        private void imgDesenho_MouseDown(object sender, MouseEventArgs e)
        {
            oPosicao.X = e.X;
            oPosicao.Y = e.Y;           
        }

        private void imgDesenho_MouseUp(object sender, MouseEventArgs e)
        {
            oimagem.DrawRectangle(new Pen(Color.Red, 10), oPosicao.X, oPosicao.Y, e.X - oPosicao.X, e.Y - oPosicao.Y);
            imgDesenho.Refresh();
        }

        private void fnmPrincipal_Load(object sender, EventArgs e)
        {
            imgDesenho.Image = new Bitmap(imgDesenho.Width, imgDesenho.Height);
            oimagem = Graphics.FromImage(imgDesenho.Image);
        }
    }
}