﻿namespace Desenhador
{
    partial class fnmPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            objMenu = new TabControl();
            mnuArquivo = new TabPage();
            mnuFerramentas = new TabPage();
            imgDesenho = new PictureBox();
            objMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)imgDesenho).BeginInit();
            SuspendLayout();
            // 
            // objMenu
            // 
            objMenu.Controls.Add(mnuArquivo);
            objMenu.Controls.Add(mnuFerramentas);
            objMenu.Dock = DockStyle.Top;
            objMenu.Location = new Point(0, 0);
            objMenu.Name = "objMenu";
            objMenu.SelectedIndex = 0;
            objMenu.Size = new Size(800, 100);
            objMenu.TabIndex = 0;
            // 
            // mnuArquivo
            // 
            mnuArquivo.Location = new Point(4, 24);
            mnuArquivo.Name = "mnuArquivo";
            mnuArquivo.Padding = new Padding(3);
            mnuArquivo.Size = new Size(792, 72);
            mnuArquivo.TabIndex = 0;
            mnuArquivo.Text = "Arquivo";
            mnuArquivo.UseVisualStyleBackColor = true;
            // 
            // mnuFerramentas
            // 
            mnuFerramentas.Location = new Point(4, 24);
            mnuFerramentas.Name = "mnuFerramentas";
            mnuFerramentas.Padding = new Padding(3);
            mnuFerramentas.Size = new Size(792, 72);
            mnuFerramentas.TabIndex = 1;
            mnuFerramentas.Text = "Ferramentas";
            mnuFerramentas.UseVisualStyleBackColor = true;
            // 
            // imgDesenho
            // 
            imgDesenho.Location = new Point(0, 93);
            imgDesenho.Name = "imgDesenho";
            imgDesenho.Size = new Size(800, 359);
            imgDesenho.TabIndex = 1;
            imgDesenho.TabStop = false;
            imgDesenho.MouseDown += imgDesenho_MouseDown;
            imgDesenho.MouseUp += imgDesenho_MouseUp;
            // 
            // fnmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(imgDesenho);
            Controls.Add(objMenu);
            Name = "fnmPrincipal";
            Text = "Desenhador";
            Load += fnmPrincipal_Load;
            objMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)imgDesenho).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl objMenu;
        private TabPage mnuArquivo;
        private TabPage mnuFerramentas;
        private PictureBox imgDesenho;
    }
}